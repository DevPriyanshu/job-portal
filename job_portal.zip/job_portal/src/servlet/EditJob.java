package servlet;

import javax.servlet.http.HttpServlet;

public class EditJob extends HttpServlet
{
	
}
